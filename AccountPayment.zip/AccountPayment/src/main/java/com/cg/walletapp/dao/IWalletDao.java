package com.cg.walletapp.dao;

import java.util.List;

import com.cg.walletapp.bean.Customer;

public interface IWalletDao {

	public void addAccountDao(Customer customer);

	public Customer findOne(String mobnum);
	
	public void addTransactions(String mobnum);
	public List<String> printTransactionsDao();
}
