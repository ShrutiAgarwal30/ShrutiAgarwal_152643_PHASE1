package com.cg.walletapp.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import com.cg.walletapp.bean.Customer;

public class WalletDaoImpl implements IWalletDao {
	public static Map<String, Customer> walletDetails = null;
	public static List<String> transactionDetails = null;
	static {
		walletDetails = new HashMap<String, Customer>();
		transactionDetails = new ArrayList<String>();
		Customer customer1 = new Customer();
		customer1.setWalletBalance(new BigDecimal("1000"));
		customer1.setName("shruti");
		customer1.setMobileNo("1234567899");
		walletDetails.put(customer1.getMobileNo(), customer1);
		Customer customer2 = new Customer();
		customer2.setWalletBalance(new BigDecimal("2000"));
		customer2.setName("shruti");
		customer2.setMobileNo("1234567890");
		walletDetails.put(customer2.getMobileNo(), customer2);
	}

	public void addAccountDao(Customer customer) {

		walletDetails.put(customer.getMobileNo(), customer);
		
	}

	public Map<String, Customer> viewDetail() {

		return walletDetails;
	}

	public Customer findOne(String mobnum) {

		Customer customersearch = new Customer();
		Set<Entry<String, Customer>> set = walletDetails.entrySet();
		Iterator<Entry<String, Customer>> it = set.iterator();
		while (it.hasNext()) {

			Map.Entry<String, Customer> entry = it.next();
			if (entry.getKey().equals(mobnum)) {
				customersearch = entry.getValue();

			}
		
		}
		return customersearch;
	}

	public void addTransactions(String str) {
	transactionDetails.add(str);
		
	}

	public List<String> printTransactionsDao() {
	
		return transactionDetails;
	}

}
