package com.cg.walletapp.test;

import junit.framework.TestCase;

public class WalletAppTest extends TestCase {

	
}
